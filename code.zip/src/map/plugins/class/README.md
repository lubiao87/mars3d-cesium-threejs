#MarsGIS Cesium 功能扩展单独ES6类
 
每一个js文件都是一个单独的类，可以单独扩展使用。

 