import navbar_icon_free from './image/population/navbar_icon_3.png'
import navbar_icon_foure from './image/population/navbar_icon_4.png'
import cabinet_ico from './image/population/cabinet_ico.png'
import conditioner_ico from './image/population/conditioner_ico.png'
// 资源信息
import wifi_data_module from './image/micromodule/wifi_data_module_img1.png'
import wifi_data_module_img2 from './image/micromodule/wifi_data_module_img2.png'
import wifi_data_module_img3 from './image/micromodule/wifi_data_module_img3.png'
import wifi_data_module_img4 from './image/micromodule/wifi_data_module_img4.png'
import navbarIconZero from './image/population/navbar_icon_0.png'
// import
export default {
    nabarCation: navbar_icon_free,
    navbarIcon: navbar_icon_foure,
    cabinetIcon: cabinet_ico,
    conditionerIco: conditioner_ico,
//    资源信息
    wifiData: wifi_data_module,
    wifiDataTwo: wifi_data_module_img2,
    wifiDataFree: wifi_data_module_img3,
    wifiDataFoure: wifi_data_module_img4,
    navbarIconZero: navbarIconZero
}